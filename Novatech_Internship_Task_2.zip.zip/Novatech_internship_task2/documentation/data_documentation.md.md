# Novatech Internship – Task 2

## Real-World Dataset Cleaning and Preprocessing

### 1. Project Overview

This project focuses on collecting, cleaning, preprocessing, and transforming a real-world dataset obtained from a public source.

The **Wine Quality – Red Wine Dataset** from the UCI Machine Learning Repository was selected for this task.

The objective was to prepare the dataset for further data analysis and machine learning applications.

---

## 2. Dataset Information

**Dataset:** Wine Quality – Red Wine Dataset

**Source:** UCI Machine Learning Repository

**Original Records:** 1,599

**Original Features:** 12

**Final Records:** 1,359

**Final Features:** 15

The dataset contains physicochemical properties of red wine samples along with a quality score.

---

## 3. Original Dataset Features

| Feature              | Description                       |
| -------------------- | --------------------------------- |
| fixed acidity        | Amount of fixed acids in the wine |
| volatile acidity     | Amount of volatile acids          |
| citric acid          | Citric acid content               |
| residual sugar       | Amount of residual sugar          |
| chlorides            | Chloride concentration            |
| free sulfur dioxide  | Free sulfur dioxide level         |
| total sulfur dioxide | Total sulfur dioxide level        |
| density              | Density of the wine               |
| pH                   | Acidity/basicity measurement      |
| sulphates            | Sulphate concentration            |
| alcohol              | Alcohol percentage                |
| quality              | Wine quality score                |

---

## 4. Data Preprocessing Pipeline

### Step 1 – Data Loading

The dataset was loaded into Python using the Pandas library.

### Step 2 – Data Inspection

The dataset structure, number of rows and columns, data types, and statistical summary were examined.

### Step 3 – Missing Value Handling

The dataset was checked for missing values using Pandas.

**Result:** No missing values were found.

Therefore, no imputation was required.

### Step 4 – Duplicate Handling

Duplicate records were identified using Pandas `duplicated()`.

**Duplicate records detected:** 240

These duplicate records were removed using `drop_duplicates()`.

**Duplicate records after cleaning:** 0

The dataset was reduced from 1,599 records to 1,359 records.

### Step 5 – Data Type Conversion

Numerical columns were explicitly converted to appropriate numeric data types using `pd.to_numeric()`.

### Step 6 – Outlier Detection

Potential outliers were identified using the Interquartile Range (IQR) method.

The limits were calculated using:

**IQR = Q3 − Q1**

**Lower Bound = Q1 − 1.5 × IQR**

**Upper Bound = Q3 + 1.5 × IQR**

### Step 7 – Outlier Treatment

Extreme numerical values were capped using the calculated IQR boundaries instead of removing complete records.

This approach helped preserve the available observations while reducing the influence of extreme values.

### Step 8 – Feature Engineering

Three additional features were created:

#### `total_acidity`

Calculated by combining:

* fixed acidity
* volatile acidity
* citric acid

#### `sulfur_dioxide_ratio`

Calculated as the ratio of free sulfur dioxide to total sulfur dioxide.

#### `alcohol_category`

Alcohol values were categorized into:

* Low
* Medium
* High

### Step 9 – Final Validation

The final dataset was checked for:

* Missing values
* Duplicate records
* Data types
* Number of records
* Number of columns
* Newly created features

### Final Results

| Validation Item               | Result |
| ----------------------------- | -----: |
| Original records              |  1,599 |
| Duplicate records removed     |    240 |
| Final records                 |  1,359 |
| Original features             |     12 |
| Final features                |     15 |
| Missing values                |      0 |
| Duplicate rows after cleaning |      0 |

The final dataset contains **1,359 records**, which satisfies the requirement of a minimum of 1,000 samples.

---

## 5. Feature Engineering Summary

| New Feature            | Description                                          |
| ---------------------- | ---------------------------------------------------- |
| `total_acidity`        | Combined acidity-related measurements                |
| `sulfur_dioxide_ratio` | Ratio of free sulfur dioxide to total sulfur dioxide |
| `alcohol_category`     | Categorizes alcohol level into Low, Medium, and High |

---

## 6. Tools and Technologies

* Python
* Pandas
* NumPy
* Google Colab
* Jupyter Notebook
* CSV

---

## 7. Project Deliverables

The project contains:

1. Raw dataset
2. Cleaned dataset
3. Data preprocessing notebook
4. Data documentation
5. README file

---

## 8. Preprocessing Pipeline

```text
Raw Dataset
     ↓
Data Inspection
     ↓
Missing Value Check
     ↓
Duplicate Detection & Removal
     ↓
Data Type Conversion
     ↓
Outlier Detection
     ↓
Outlier Treatment
     ↓
Feature Engineering
     ↓
Final Validation
     ↓
Clean Dataset
```

---

## 9. Conclusion

The Wine Quality dataset was successfully collected from a public data source and processed using Python.

The preprocessing workflow handled data-quality requirements including missing-value analysis, duplicate removal, data-type conversion, outlier detection and treatment, and feature engineering.

After preprocessing, the dataset contains **1,359 records and 15 features**, with **no missing values and no duplicate records**.

The resulting dataset is ready for further exploratory data analysis and machine learning applications.
