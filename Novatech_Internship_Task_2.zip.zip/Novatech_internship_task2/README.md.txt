# Novatech Internship – Task 2

## Real-World Dataset Cleaning and Preprocessing

### 📌 Project Overview

This project demonstrates the collection, cleaning, preprocessing, and feature engineering of a real-world dataset obtained from a public data source.

The **Wine Quality – Red Wine Dataset** from the UCI Machine Learning Repository was selected for this task.

### 🎯 Objectives

* Collect a real-world dataset containing at least 1,000 samples
* Inspect and understand the dataset
* Handle missing values
* Detect and remove duplicate records
* Convert data types where required
* Detect and treat outliers
* Perform feature engineering
* Validate the cleaned dataset
* Document the preprocessing pipeline

### 📊 Dataset

**Dataset:** Wine Quality – Red Wine Dataset
**Source:** UCI Machine Learning Repository
**Original Samples:** 1,599
**Original Features:** 12

### 🛠️ Technologies Used

* Python
* Pandas
* NumPy
* Google Colab
* Jupyter Notebook

### 🔄 Preprocessing Pipeline

```text
Raw Dataset
     ↓
Data Inspection
     ↓
Missing Value Check
     ↓
Duplicate Removal
     ↓
Data Type Conversion
     ↓
Outlier Detection
     ↓
Outlier Treatment
     ↓
Feature Engineering
     ↓
Final Validation
     ↓
Clean Dataset
```

### ✨ Feature Engineering

The following features were created:

* `total_acidity`
* `sulfur_dioxide_ratio`
* `alcohol_category`

### 📁 Project Structure

```text
Novatech_Internship_Task_2/
│
├── data/
│   ├── winequality-red.csv
│   └── winequality_cleaned.csv
│
├── notebook/
│   └── Novatech_Task_2_Data_Preprocessing.ipynb
│
├── documentation/
│   └── data_documentation.md
│
├── scripts/
│
└── README.md
```

### 📦 Deliverables

* Raw dataset
* Cleaned dataset
* Preprocessing notebook
* Data documentation
* README file

### 🏁 Conclusion

The dataset was successfully cleaned and transformed using a structured preprocessing pipeline. The resulting dataset is ready for further analysis and machine learning applications.
